import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    cardHolder: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: ''
  });

  const [isFlipped, setIsFlipped] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCardDetails({ ...cardDetails, [name]: value });
  };

  const handleFocus = () => {
    setIsFlipped(true);
  };

  const handleBlur = () => {
    setIsFlipped(false);
  };

  useEffect(() => {
    const card = document.querySelector('.card');
    const handleMouseMove = (e) => {
      const { offsetWidth: width, offsetHeight: height } = card;
      const { clientX: x, clientY: y } = e;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const moveX = (x - centerX) / centerX * 15;
      const moveY = (y - centerY) / centerY * 15;
      card.style.transform = `rotateY(${moveX}deg) rotateX(${-moveY}deg)`;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', () => {
      card.style.transform = 'rotateY(0deg) rotateX(0deg)';
    });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', () => {
        card.style.transform = 'rotateY(0deg) rotateX(0deg)';
      });
    };
  }, []);

  return (
    <div className="App">
      <div className="content">
        <div className="card-container">
          <div className={`card ${isFlipped ? 'flipped' : ''}`}>
            <div className="card-front">
              <div className="card-logo">VISA</div>
              <div className="card-number">{cardDetails.cardNumber || '#### #### #### ####'}</div>
              <div className="card-details">
                <div className="card-holder">{cardDetails.cardHolder || 'Card Holder'}</div>
                <div className="card-expiry">
                  {cardDetails.expiryMonth || 'MM'}/{cardDetails.expiryYear || 'YY'}
                </div>
              </div>
            </div>
            <div className="card-back">
              <div className="card-cvv">{cardDetails.cvv || 'CVV'}</div>
            </div>
          </div>
        </div>
        <div className="card-form">
          <input
            type="text"
            name="cardNumber"
            placeholder="Card Number"
            value={cardDetails.cardNumber}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="cardHolder"
            placeholder="Card Holder"
            value={cardDetails.cardHolder}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="expiryMonth"
            placeholder="Expiry Month"
            value={cardDetails.expiryMonth}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="expiryYear"
            placeholder="Expiry Year"
            value={cardDetails.expiryYear}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="cvv"
            placeholder="CVV"
            value={cardDetails.cvv}
            onChange={handleInputChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
          />
        </div>
      </div>
    </div>
  );
};

export default App;